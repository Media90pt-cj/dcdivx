
// portab.h //

#ifndef _PORTAB_H_
#define _PORTAB_H_

// basic types

#define int8_t char
#define uint8_t unsigned char
#define int16_t short
#define uint16_t unsigned short
#define int32_t int
#define uint32_t unsigned int 
#define int64_t __int64
#define uint64_t unsigned __int64
#define idct_block_t int
int g_Extra;
#endif // _PORTAB_H_
